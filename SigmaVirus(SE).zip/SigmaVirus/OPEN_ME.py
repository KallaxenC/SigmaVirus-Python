import os
from tkinter import messagebox as mb
from time import sleep

start = mb.askyesno(message="This is a computer virus. Are you sure you would like to continue?", title="Continue?")

if start == True:
    os.startfile("video1.mp4")
    sleep(9)
    os.startfile("1.py")
else:
    exit()
